import { Shield, FileText, TrendingUp, Settings } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Moderation",
    description: "Complete moderation suite with ban, kick, mute, tempban, softban, warn, and comprehensive logging.",
    features: [
      "Advanced punishment system",
      "Automatic moderation logs",
      "Customizable warnings"
    ]
  },
  {
    icon: FileText,
    title: "Logging",
    description: "Track all server activity with detailed logs for joins, leaves, message changes, and role updates.",
    features: [
      "Member join/leave tracking",
      "Message edit/delete logs",
      "Role and nickname changes"
    ]
  },
  {
    icon: TrendingUp,
    title: "Leveling",
    description: "Engage your community with XP system, ranks, and competitive leaderboards.",
    features: [
      "XP and ranking system",
      "Interactive leaderboards",
      "Customizable level rewards"
    ]
  },
  {
    icon: Settings,
    title: "Utility",
    description: "Essential server tools including server info, user info, memes, avatars, and welcome messages.",
    features: [
      "Server and user information",
      "Entertainment commands",
      "Welcome message system"
    ]
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Powerful <span className="text-primary">Features</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to manage your Discord server efficiently and effectively
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div 
                key={feature.title} 
                className="feature-card p-8 rounded-2xl hover:scale-105 transition-all duration-300"
                data-testid={`card-feature-${feature.title.toLowerCase()}`}
              >
                <div className="w-16 h-16 bg-primary/20 rounded-xl flex items-center justify-center mb-6">
                  <IconComponent className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground mb-4">{feature.description}</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {feature.features.map((item, itemIndex) => (
                    <li key={itemIndex}>• {item}</li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
