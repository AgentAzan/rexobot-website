import logoPath from "@assets/ChatGPT Image Sep 17, 2025, 07_29_26 PM_1758138535675.png";

export default function Hero() {
  return (
    <section className="hero-gradient min-h-screen flex items-center justify-center pt-20">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Rexo Logo */}
          <div className="w-32 h-32 mx-auto mb-8 fade-in-up">
            <img 
              src={logoPath} 
              alt="Rexo Discord Bot Logo" 
              className="w-full h-full object-cover rounded-full shadow-2xl"
              data-testid="img-hero-logo"
            />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 fade-in-up stagger-1">
            <span 
              className="bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
              data-testid="text-hero-title"
            >
              Rexo
            </span>
          </h1>
          
          <p 
            className="text-xl md:text-2xl text-muted-foreground mb-12 fade-in-up stagger-2 max-w-2xl mx-auto"
            data-testid="text-hero-tagline"
          >
            The all-in-one moderation and leveling bot for Discord
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center fade-in-up stagger-3">
            <a 
              href="https://discord.com/api/oauth2/authorize?client_id=1398582139464847411&permissions=1374540622870&scope=bot%20applications.commands" 
              className="btn-primary px-8 py-4 rounded-xl font-semibold text-lg w-full sm:w-auto" 
              target="_blank" 
              rel="noopener noreferrer"
              data-testid="button-invite-primary"
            >
              Invite Rexo
            </a>
            <a 
              href="https://discord.gg/uXWMaUdRvV" 
              className="btn-secondary px-8 py-4 rounded-xl font-semibold text-lg w-full sm:w-auto" 
              target="_blank" 
              rel="noopener noreferrer"
              data-testid="button-support-primary"
            >
              Join Support Server
            </a>
          </div>
          
          <div className="mt-16 text-sm text-muted-foreground fade-in-up stagger-4">
            <span>
              Default prefix: <code className="bg-muted px-2 py-1 rounded text-foreground">..</code>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
