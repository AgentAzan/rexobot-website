export default function Footer() {
  return (
    <footer className="bg-background border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-3 mb-4 md:mb-0">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold">R</span>
            </div>
            <span className="text-lg font-bold text-foreground">Rexo</span>
          </div>
          
          <div className="flex items-center space-x-6 mb-4 md:mb-0">
            <a 
              href="https://discord.com/api/oauth2/authorize?client_id=1398582139464847411&permissions=1374540622870&scope=bot%20applications.commands" 
              className="text-muted-foreground hover:text-primary transition-colors" 
              target="_blank" 
              rel="noopener noreferrer"
              data-testid="link-invite-footer"
            >
              Invite
            </a>
            <a 
              href="https://discord.gg/uXWMaUdRvV" 
              className="text-muted-foreground hover:text-primary transition-colors" 
              target="_blank" 
              rel="noopener noreferrer"
              data-testid="link-support-footer"
            >
              Support
            </a>
          </div>
          
          <div className="text-sm text-muted-foreground">
            © 2025 Rexo. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
