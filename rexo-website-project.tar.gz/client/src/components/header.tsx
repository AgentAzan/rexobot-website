import { useState } from "react";
import { Menu, X } from "lucide-react";
import logoPath from "@assets/ChatGPT Image Sep 17, 2025, 07_29_26 PM_1758138535675.png";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <img 
            src={logoPath} 
            alt="Rexo Discord Bot Logo" 
            className="w-10 h-10 object-cover rounded-full"
            data-testid="img-header-logo"
          />
          <span className="text-xl font-bold text-foreground">Rexo</span>
        </div>
        
        <div className="hidden md:flex items-center space-x-4">
          <button 
            onClick={() => scrollToSection('features')} 
            className="text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-features"
          >
            Features
          </button>
          <button 
            onClick={() => scrollToSection('commands')} 
            className="text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-commands"
          >
            Commands
          </button>
          <a 
            href="https://discord.com/api/oauth2/authorize?client_id=1398582139464847411&permissions=1374540622870&scope=bot%20applications.commands" 
            className="btn-primary px-4 py-2 rounded-lg font-medium text-sm" 
            target="_blank" 
            rel="noopener noreferrer"
            data-testid="button-invite-header"
          >
            Invite Rexo
          </a>
        </div>
        
        {/* Mobile menu button */}
        <button 
          className="md:hidden text-foreground" 
          onClick={toggleMobileMenu}
          data-testid="button-mobile-menu"
        >
          {isMobileMenuOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <Menu className="w-6 h-6" />
          )}
        </button>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-t border-border">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <button 
              onClick={() => scrollToSection('features')} 
              className="block text-muted-foreground hover:text-foreground transition-colors w-full text-left"
              data-testid="link-features-mobile"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('commands')} 
              className="block text-muted-foreground hover:text-foreground transition-colors w-full text-left"
              data-testid="link-commands-mobile"
            >
              Commands
            </button>
            <a 
              href="https://discord.com/api/oauth2/authorize?client_id=1398582139464847411&permissions=1374540622870&scope=bot%20applications.commands" 
              className="block btn-primary px-4 py-2 rounded-lg font-medium text-sm text-center" 
              target="_blank" 
              rel="noopener noreferrer"
              data-testid="button-invite-mobile"
            >
              Invite Rexo
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
