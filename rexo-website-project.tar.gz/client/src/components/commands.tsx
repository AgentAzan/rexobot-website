import { Heart, Shield, Edit, Settings, TrendingUp } from "lucide-react";

const commandCategories = [
  {
    title: "Core Commands",
    icon: Heart,
    commands: ["help", "ping", "uptime", "avatar", "userinfo", "serverinfo", "meme", "test"]
  },
  {
    title: "Moderation",
    icon: Shield,
    commands: ["clear", "kick", "ban", "softban", "tempban", "unban", "mute", "unmute", "warn", "unwarn", "warnings"]
  },
  {
    title: "Channel & Role",
    icon: Edit,
    commands: ["lock", "unlock", "slowmode", "unslowmode", "move", "nick", "roleinfo", "channelinfo"]
  },
  {
    title: "Settings",
    icon: Settings,
    commands: ["prefix", "setwelcome", "log"]
  }
];

const levelingCommands = {
  title: "Leveling Commands",
  icon: TrendingUp,
  commands: ["enableleveling", "disableleveling", "rank", "leaderboard"]
};

export default function Commands() {
  return (
    <section id="commands" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Command <span className="text-primary">Reference</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive list of all available commands organized by category
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {commandCategories.map((category) => {
            const IconComponent = category.icon;
            return (
              <div 
                key={category.title} 
                className="command-section rounded-2xl p-8"
                data-testid={`section-commands-${category.title.toLowerCase().replace(' ', '-')}`}
              >
                <h3 className="text-2xl font-bold mb-6 text-primary flex items-center">
                  <IconComponent className="w-6 h-6 mr-3" />
                  {category.title}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {category.commands.map((command) => (
                    <div 
                      key={command} 
                      className="bg-background/50 rounded-lg p-3 border border-border"
                      data-testid={`command-${command}`}
                    >
                      <code className="text-primary font-medium">..{command}</code>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Leveling Commands */}
        <div className="mt-8">
          <div 
            className="command-section rounded-2xl p-8 max-w-2xl mx-auto"
            data-testid="section-commands-leveling"
          >
            <h3 className="text-2xl font-bold mb-6 text-primary flex items-center justify-center">
              <TrendingUp className="w-6 h-6 mr-3" />
              {levelingCommands.title}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {levelingCommands.commands.map((command) => (
                <div 
                  key={command} 
                  className="bg-background/50 rounded-lg p-3 border border-border"
                  data-testid={`command-${command}`}
                >
                  <code className="text-primary font-medium">..{command}</code>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
