import Header from "@/components/header";
import Hero from "@/components/hero";
import Features from "@/components/features";
import Commands from "@/components/commands";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground smooth-scroll">
      <Header />
      <Hero />
      <Features />
      <Commands />
      <Footer />
    </div>
  );
}
